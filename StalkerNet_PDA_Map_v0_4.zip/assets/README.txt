Place your high-resolution Anomaly map image in this folder and name it:

anomaly-zone-map.jpg

Recommended source options I found:
1) Fandom interactive map pages (CC-BY-SA)
2) ModDB high resolution PDA map addon (but note ModDB lists the addon as Proprietary, so do not redistribute it without permission)

Current script.js assumes a tall map around 3840 x 9788.
If your chosen map uses a different size or layout, you may want to update the marker x/y coordinates in script.js.
